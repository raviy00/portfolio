'use client';
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Menu, X } from 'lucide-react';
import { APP_LOGO, APP_TITLE } from '@/const';
import LoadingPage from '@/components/LoadingPage';
import AccordionMenu from '@/components/AccordionMenu';
import Enhanced3DBackground from '@/components/Enhanced3DBackground';
import Section3DTransition from '@/components/Section3DTransition';
import ContactForm from '@/components/ContactForm';
import ThemeToggle from '@/components/ThemeToggle';
import LanguageSelector from '@/components/LanguageSelector';
import TestimonialsSection from '@/components/TestimonialsSection';
import SkillsSection from '@/components/SkillsSection';
import NewsletterSignup from '@/components/NewsletterSignup';
import CertificationsSection from '@/components/CertificationsSection';
import { useTranslation, useLanguage } from '@/contexts/LanguageContext';
import LottiePlayer from '@/components/LottiePlayer';

const services = [
  {
    icon: '🤖',
    title: 'Telegram Bot Development',
    description: 'Creating intelligent Telegram bots with AI integration, advanced moderation, and automation features for various use cases.',
  },
  {
    icon: '🐍',
    title: 'Python Automation',
    description: 'Building powerful automation scripts and tools using Python for data processing, web scraping, and workflow optimization.',
  },
  {
    icon: '🔌',
    title: 'API Integration',
    description: 'Expert integration with various APIs including TMDB, YouTube, Weather APIs, and custom REST API development.',
  },
  {
    icon: '🔐',
    title: 'Security Research',
    description: 'Educational security tools and research projects for authorized testing and learning purposes only.',
  },
  {
    icon: '🤖',
    title: 'Machine Learning',
    description: 'ML model development and deployment using FastAPI, Streamlit, and popular frameworks for intelligent applications.',
  },
  {
    icon: '📊',
    title: 'Data Analysis',
    description: 'Data processing, visualization, and analysis projects including wine quality prediction and iris classification.',
  },
];

const inProgressProjects = [
  {
    icon: '🌱',
    title: 'Carbon Footprint Calculator',
    description: 'An innovative application to calculate and track carbon emissions. Helps users understand their environmental impact and provides actionable insights for reducing carbon footprint.',
    status: 'ACTIVE_DEV',
    tech: 'Python, API_Integration',
    statusColor: '#00ff00',
  },
  {
    icon: '📡',
    title: 'Bluetooth Mesh Network',
    description: 'Developing a robust Bluetooth mesh networking solution for IoT devices. Enables seamless device-to-device communication and creates scalable smart device networks.',
    status: 'ACTIVE_DEV',
    tech: 'Bluetooth_LE, Mesh_Protocol',
    statusColor: '#00aaff',
  },
];

const completedProjects = [
  {
    icon: '🤖',
    title: 'AI Group Manager Bot',
    description: 'A professional, AI-powered Telegram group management bot with advanced moderation features. MIT Licensed. Built with intelligent automation for group administration.',
    github_url: 'https://github.com/Raviraviy00/Group-manager-bot',
  },
  {
    icon: '🎬',
    title: 'Movie & Series Recommendation Bot',
    description: 'A fully functional Telegram bot that recommends movies and TV series using the TMDB API. Features genre-based recommendations, search, trending content, and personal watchlist.',
    github_url: 'https://github.com/Raviraviy00/Movie-Series-Recommendation-Telegram-Bot',
  },
  {
    icon: '📥',
    title: 'Link to File Telegram Bot',
    description: 'Feature-rich Telegram bot for downloading files from various sources with specialized YouTube support, audio extraction, and animated progress tracking. MIT Licensed.',
    github_url: 'https://github.com/Raviraviy00/Link-to-file-Telegram-bot',
  },
  {
    icon: '🔐',
    title: 'Keylogger (Educational)',
    description: 'Cross-platform keylogging solution for educational and authorized security testing purposes only. Demonstrates security concepts for learning.',
    github_url: 'https://github.com/Raviraviy00/Keylogger-free-version',
  },
  {
    icon: '🌦️',
    title: 'SOP Project',
    description: 'Travel advisory and Open Weather API integration project. Testing various API functionalities for real-world applications.',
    github_url: 'https://github.com/Raviraviy00/SOP-project',
  },
  {
    icon: '🍷',
    title: 'Wine Quality Prediction',
    description: 'Machine learning application for predicting wine quality using data analysis and ML algorithms. Built with Jupyter Notebook.',
    github_url: 'https://github.com/Raviraviy00/wine-quality-app',
  },
];

export default function Home() {
  const t = useTranslation();
  const { language } = useLanguage();
  const [isLoading, setIsLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      const sections = document.querySelectorAll('section');
      let current = 'home';

      sections.forEach((section) => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        if (window.scrollY >= sectionTop - 100) {
          current = section.getAttribute('id') || 'home';
        }
      });

      setActiveSection(current);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Setup IntersectionObserver for scroll animations
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
            observer.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px',
      }
    );

    // Observe all scroll-animate elements
    const animateElements = document.querySelectorAll('.scroll-animate');
    animateElements.forEach((el) => {
      observer.observe(el);
    });

    return () => {
      animateElements.forEach((el) => {
        observer.unobserve(el);
      });
    };
  }, [isLoading]);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  if (isLoading) {
    return <LoadingPage onComplete={() => setIsLoading(false)} />;
  }

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Enhanced 3D Background */}
      <Enhanced3DBackground />

      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-background/95 backdrop-blur border-b border-dashed border-border z-40">
        <div className="container flex justify-between items-center py-4 px-4 md:px-6" style={{paddingTop: '20px'}}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 border-2 border-dashed border-accent rounded-full flex items-center justify-center text-lg animate-rotate">
              R
            </div>
            <span className="text-lg md:text-xl font-bold uppercase tracking-wider">Raviraviy00</span>
          </div>

          {/* Desktop Menu */}
          <ul className="hidden md:flex gap-4 lg:gap-8 items-center">
            {[
              { label: t.home, href: '#home' },
              { label: t.about, href: '#about' },
              { label: t.services, href: '#services' },
              { label: t.projects, href: '#projects' },
              { label: t.caseStudies, href: '/case-studies' },
              { label: 'Blog', href: '/blog' },
              { label: t.contact, href: '#contact' },
            ].map((item) => (
              <li key={item.href}>
                <a
                  href={item.href}
                  onClick={(e) => handleNavClick(e, item.href)}
                  className={`nav-link ${activeSection === item.href.slice(1) ? 'active' : ''}`}
                >
                  {item.label}
                </a>
              </li>
            ))}
            <li className="flex items-center gap-2">
              <ThemeToggle />
              <LanguageSelector />
            </li>
          </ul>

          {/* Mobile Menu Button and Theme Toggle */}
          <div className="flex items-center gap-2 md:hidden">
            <ThemeToggle />
            <LanguageSelector />
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="p-2 hover:text-accent transition-colors"
            >
              {menuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </nav>

      {/* Accordion Menu */}
      <AccordionMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />

      {/* Hero Section */}
      <Section3DTransition sectionId="home">
      <section className="min-h-screen flex items-center pt-20 pb-20 relative z-10">
        <div className="container grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center px-4 md:px-6" style={{marginTop: '150px'}}>
          <div className="space-y-6">
            <div className="text-sm uppercase tracking-widest text-muted-foreground">{t.helloIm}</div>
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold uppercase tracking-widest">
              Ravi <span className="text-accent"></span>
            </h1>
            <h2 className="text-xl sm:text-2xl md:text-3xl font-semibold uppercase tracking-wider">{t.softwareDeveloper}</h2>
            <p className="text-base sm:text-lg text-muted-foreground leading-relaxed">
              {t.bio}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4" style={{paddingTop: '20px'}}>
              <Button className="btn-primary text-sm sm:text-base">{t.getStarted}</Button>
              <Button className="btn-secondary text-sm sm:text-base" style={{paddingLeft: '30px'}}>{t.viewProjects}</Button>
            </div>
          </div>
          <div className="flex justify-center">
            <div className="w-full max-w-md overflow-hidden">
              <LottiePlayer src="/profile.json" loop autoplay speed={1} />
            </div>
          </div>
        </div>
      </section>
      </Section3DTransition>

      {/* About Section */}
      <Section3DTransition sectionId="about" delay={0.2}>
      <section className="py-20 bg-card/50 relative z-10">
        <div className="container">
          <h2 className="section-title mb-12">{t.aboutMe}</h2>
          <div className="max-w-3xl mx-auto space-y-12">
            <div className="text-center space-y-6">
              <p className="text-lg text-muted-foreground leading-relaxed">
                {t.aboutText1}
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                {t.aboutText2}
              </p>
            </div>
            
            <div className="border-t border-dashed border-border pt-12">
              <h3 className="text-xl md:text-2xl font-bold uppercase tracking-widest mb-8 text-center">{t.languages}</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
                <div className="text-center p-4 md:p-6 border-2 border-dashed border-border rounded">
                  <p className="text-base md:text-lg font-semibold text-accent mb-2">Sinhala</p>
                  <p className="text-sm md:text-base text-muted-foreground">{t.sinhala}</p>
                </div>
                <div className="text-center p-4 md:p-6 border-2 border-dashed border-border rounded">
                  <p className="text-base md:text-lg font-semibold text-accent mb-2">English</p>
                  <p className="text-sm md:text-base text-muted-foreground">{t.english}</p>
                </div>
                <div className="text-center p-4 md:p-6 border-2 border-dashed border-border rounded">
                  <p className="text-base md:text-lg font-semibold text-accent mb-2">German</p>
                  <p className="text-sm md:text-base text-muted-foreground">{t.german}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      </Section3DTransition>

      {/* Services Section */}
      <Section3DTransition sectionId="services" delay={0.3}>
      <section className="py-16 md:py-20 relative z-10 px-4 md:px-6">
        <div className="container">
          <h2 className="section-title mb-8 md:mb-12">{t.services_title}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            {[
              { icon: 'BOT', title: t.telegramBot, description: t.telegramBotDesc },
              { icon: 'PY', title: t.pythonAutomation, description: t.pythonAutomationDesc },
              { icon: 'API', title: t.apiIntegration, description: t.apiIntegrationDesc },
              { icon: 'SEC', title: t.securityResearch, description: t.securityResearchDesc },
              { icon: 'ML', title: t.machineLearning, description: t.machineLearningDesc },
              { icon: 'DATA', title: t.dataAnalysis, description: t.dataAnalysisDesc },
            ].map((service, idx) => (
              <div key={idx} className="card-dotted scroll-animate" style={{ transitionDelay: `${idx * 0.1}s` }}>
                <div className="glyph-circle mb-6 text-4xl md:text-5xl">{service.icon}</div>
                <h3 className="text-lg md:text-xl font-bold uppercase tracking-wider mb-4">{service.title}</h3>
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      </Section3DTransition>

      {/* In-Progress Projects Section */}
      <Section3DTransition sectionId="in-progress" delay={0.4}>
      <section className="py-16 md:py-20 bg-card/50 relative z-10 px-4 md:px-6">
        <div className="container">
          <h3 className="text-xl md:text-2xl font-bold uppercase tracking-widest text-center mb-8 md:mb-12">{t.inProgress}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
            {[
              { icon: 'CF', titleKey: 'carbonFootprintTitle', descKey: 'carbonFootprintDesc', status: 'ACTIVE_DEV', tech: 'Python, API_Integration', statusColor: '#00ff00' },
              { icon: 'BT', titleKey: 'bluetoothMeshTitle', descKey: 'bluetoothMeshDesc', status: 'ACTIVE_DEV', tech: 'Bluetooth_LE, Mesh_Protocol', statusColor: '#00aaff' },
            ].map((project, idx) => (
              <div key={idx} className="relative border-2 border-solid border-accent bg-transparent p-4 md:p-6 overflow-visible">
                <div className="absolute -top-4 -right-2 bg-accent text-accent-foreground px-4 py-2 text-xs font-bold uppercase tracking-wider">
                  {t.inProgress}
                </div>
                <div className="text-6xl mb-6 text-center">{project.icon}</div>
                <h4 className="text-lg md:text-xl font-bold uppercase tracking-wider mb-4">{t[project.titleKey as keyof typeof t]}</h4>
                <p className="text-sm md:text-base text-muted-foreground mb-6 leading-relaxed">{t[project.descKey as keyof typeof t]}</p>
                <div
                  className="p-3 border border-dashed text-xs font-mono"
                  style={{
                    borderColor: project.statusColor,
                    color: project.statusColor,
                  }}
                >
                  <strong>STATUS:</strong> {project.status} | <strong>TECH:</strong> {project.tech}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      </Section3DTransition>

      {/* Completed Projects Section */}
      <Section3DTransition sectionId="projects" delay={0.5}>
      <section className="py-16 md:py-20 relative z-10 px-4 md:px-6">
        <div className="container">
          <h3 className="text-xl md:text-2xl font-bold uppercase tracking-widest text-center mb-8 md:mb-12">{language === 'de' ? 'ABGESCHLOSSENE_PROJEKTE' : 'COMPLETED_PROJECTS'}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            {[
              { icon: 'BOT', titleKey: 'aiGroupBotTitle', descKey: 'aiGroupBotDesc', github_url: 'https://github.com/Raviraviy00/Group-manager-bot' },
              { icon: 'MOVIE', titleKey: 'movieBotTitle', descKey: 'movieBotDesc', github_url: 'https://github.com/Raviraviy00/Movie-Series-Recommendation-Telegram-Bot' },
              { icon: 'LINK', titleKey: 'linkToBotTitle', descKey: 'linkToBotDesc', github_url: 'https://github.com/Raviraviy00/Link-to-file-Telegram-bot' },
              { icon: 'KEY', titleKey: 'keyloggerTitle', descKey: 'keyloggerDesc', github_url: 'https://github.com/Raviraviy00/Keylogger-free-version' },
              { icon: 'SOP', titleKey: 'sopProjectTitle', descKey: 'sopProjectDesc', github_url: 'https://github.com/Raviraviy00/SOP-project' },
              { icon: 'WINE', titleKey: 'wineQualityTitle', descKey: 'wineQualityDesc', github_url: 'https://github.com/Raviraviy00/wine-quality-app' },
            ].map((project, idx) => (
              <div key={idx} className="card-dotted flex flex-col scroll-animate" style={{ transitionDelay: `${idx * 0.1}s` }}>
                <div className="text-4xl md:text-5xl mb-6 text-center">{project.icon}</div>
                <h4 className="text-base md:text-lg font-bold uppercase tracking-wider mb-4 flex-grow">{t[project.titleKey as keyof typeof t]}</h4>
                <p className="text-xs md:text-sm text-muted-foreground mb-6 leading-relaxed">{t[project.descKey as keyof typeof t]}</p>
                <a
                  href={project.github_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary inline-block text-center"
                >
                  {t.viewOnGithub}
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>
      </Section3DTransition>

      {/* Testimonials Section */}
      <Section3DTransition sectionId="testimonials" delay={0.55}>
      <TestimonialsSection />
      </Section3DTransition>

      {/* Skills Section */}
      <Section3DTransition sectionId="skills" delay={0.57}>
      <SkillsSection />
      </Section3DTransition>

      {/* Certifications Section */}
      <Section3DTransition sectionId="certifications" delay={0.58}>
      <CertificationsSection />
      </Section3DTransition>

      {/* Newsletter Section */}
      <Section3DTransition sectionId="newsletter" delay={0.59}>
      <NewsletterSignup />
      </Section3DTransition>

      {/* Contact Section */}
      <Section3DTransition sectionId="contact" delay={0.6}>
      <section className="py-16 md:py-20 bg-card/50 relative z-10 px-4 md:px-6">
        <div className="container">
          <h2 className="section-title mb-8 md:mb-12">{t.getInTouch}</h2>
          <ContactForm />
        </div>
      </section>
      </Section3DTransition>

      {/* Footer */}
      <footer className="py-6 md:py-8 bg-card border-t border-dashed border-border text-center text-xs md:text-sm text-muted-foreground relative z-10 px-4">
        <p className="break-words">&copy; 2025 Ravi (Raviraviy00). {t.allRightsReserved}. | {t.colombo}</p>
      </footer>
    </div>
  );
}
