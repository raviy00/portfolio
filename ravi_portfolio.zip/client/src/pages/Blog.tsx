import { useScrollAnimation } from '@/hooks/useScrollAnimation';

interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  date: string;
  category: string;
  readTime: string;
  content: string;
}

export default function Blog() {
  const ref = useScrollAnimation();

  const blogPosts: BlogPost[] = [
    {
      id: 1,
      title: 'Building Scalable Telegram Bots with FastAPI',
      excerpt: 'Learn how to create high-performance Telegram bots using FastAPI and async programming patterns.',
      date: 'November 15, 2024',
      category: 'Tutorial',
      readTime: '8 min read',
      content: `Building scalable Telegram bots requires careful consideration of architecture and performance patterns. In this comprehensive guide, we'll explore how to leverage FastAPI to create bots that can handle thousands of concurrent users.

Key topics covered:
- Setting up FastAPI with Telegram Bot API
- Implementing webhook handlers
- Database integration with async drivers
- Error handling and logging
- Deployment strategies

FastAPI provides excellent async support out of the box, making it ideal for I/O-bound operations like API calls to Telegram servers. By using proper async patterns, you can handle multiple user requests simultaneously without blocking.`,
    },
    {
      id: 2,
      title: 'Security Research: Common Python Automation Pitfalls',
      excerpt: 'Discover the most common security vulnerabilities in Python automation scripts and how to prevent them.',
      date: 'November 10, 2024',
      category: 'Security',
      readTime: '10 min read',
      content: `Security is paramount when developing automation tools. This article explores the most common vulnerabilities found in Python automation scripts and provides practical solutions.

Critical security considerations:
- Input validation and sanitization
- Secure credential management
- API rate limiting and abuse prevention
- SQL injection prevention
- Secure file handling

Many developers overlook security when building automation tools, assuming they're only used internally. However, best practices should always be followed to prevent potential exploits.`,
    },
    {
      id: 3,
      title: 'Getting Started with Machine Learning in Python',
      excerpt: 'An introduction to machine learning concepts and popular Python libraries for data analysis.',
      date: 'November 5, 2024',
      category: 'Machine Learning',
      readTime: '12 min read',
      content: `Machine learning is transforming how we solve complex problems. This beginner-friendly guide introduces fundamental concepts and shows how to get started with popular Python libraries.

Topics include:
- Supervised vs unsupervised learning
- Data preprocessing and feature engineering
- Popular libraries: scikit-learn, pandas, numpy
- Building your first classification model
- Model evaluation and validation

Python's rich ecosystem of machine learning libraries makes it the go-to choice for data scientists and engineers worldwide.`,
    },
  ];

  return (
    <div ref={ref} className="min-h-screen bg-background relative z-10">
      {/* Header */}
      <div className="py-16 md:py-24 bg-card/50 px-4 md:px-6">
        <div className="container">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold uppercase tracking-widest mb-4">
            // Blog
          </h1>
          <p className="text-base md:text-lg text-muted-foreground">
            Technical insights, tutorials, and security research
          </p>
        </div>
      </div>

      {/* Blog Posts */}
      <section className="py-16 md:py-20 px-4 md:px-6">
        <div className="container">
          <div className="space-y-8 md:space-y-12">
            {blogPosts.map((post, idx) => (
              <article
                key={post.id}
                className="scroll-animate card-dotted"
                style={{ transitionDelay: `${idx * 0.1}s` }}
              >
                <div className="flex flex-col md:flex-row justify-between md:items-start gap-4 mb-4">
                  <div>
                    <div className="flex flex-wrap gap-2 mb-3">
                      <span className="inline-block px-3 py-1 text-xs md:text-sm font-semibold uppercase tracking-wider border border-dashed border-accent text-accent">
                        {post.category}
                      </span>
                      <span className="inline-block px-3 py-1 text-xs md:text-sm text-muted-foreground">
                        {post.readTime}
                      </span>
                    </div>
                    <h2 className="text-xl md:text-2xl font-bold uppercase tracking-wider mb-3">
                      {post.title}
                    </h2>
                  </div>
                  <p className="text-sm md:text-base text-muted-foreground whitespace-nowrap">
                    {post.date}
                  </p>
                </div>
                
                <p className="text-base md:text-lg text-muted-foreground leading-relaxed mb-4">
                  {post.excerpt}
                </p>

                <div className="border-t border-dashed border-border pt-4">
                  <p className="text-sm md:text-base text-muted-foreground leading-relaxed whitespace-pre-line">
                    {post.content.substring(0, 300)}...
                  </p>
                  <button className="mt-4 btn-secondary text-sm md:text-base">
                    Read Full Article
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
