import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { useLocation } from 'wouter';
import Enhanced3DBackground from '@/components/Enhanced3DBackground';
import Section3DTransition from '@/components/Section3DTransition';

interface CaseStudy {
  id: string;
  title: string;
  category: string;
  description: string;
  challenge: string;
  solution: string;
  results: string[];
  technologies: string[];
  date: string;
}

const caseStudies: CaseStudy[] = [
  {
    id: 'telegram-bot-ai',
    title: 'Advanced Telegram Bot with AI Integration',
    category: 'Telegram Bot Development',
    description: 'A sophisticated Telegram bot that leverages AI for intelligent responses, user moderation, and automated workflows.',
    challenge: 'Creating a bot that could handle complex user interactions, moderate content intelligently, and integrate with multiple APIs while maintaining performance under high load.',
    solution: 'Developed a multi-threaded Python application using the Telegram Bot API, integrated GPT-based AI for natural language processing, implemented Redis for caching, and used asyncio for efficient concurrent operations.',
    results: [
      'Reduced response time by 60% through intelligent caching',
      'Achieved 99.9% uptime with automatic error recovery',
      'Processed 10,000+ user interactions daily without performance degradation',
      'Reduced moderation workload by 80% with AI-powered filtering'
    ],
    technologies: ['Python', 'Telegram Bot API', 'GPT API', 'Redis', 'PostgreSQL', 'Docker'],
    date: '2024'
  },
  {
    id: 'web-scraping-pipeline',
    title: 'Large-Scale Web Scraping Pipeline',
    category: 'Python Automation',
    description: 'Built an enterprise-grade web scraping pipeline that collects, processes, and analyzes data from multiple sources in real-time.',
    challenge: 'Handling rate limiting, proxy rotation, dynamic content loading, and ensuring data accuracy while processing millions of records daily.',
    solution: 'Implemented a distributed scraping system using Scrapy framework, integrated Selenium for JavaScript-heavy sites, used rotating proxies for reliability, and built a data validation pipeline with error handling.',
    results: [
      'Scraped 5 million+ records daily with 99.5% accuracy',
      'Reduced scraping time by 70% through parallelization',
      'Implemented automatic error recovery and retry mechanisms',
      'Created comprehensive monitoring and alerting system'
    ],
    technologies: ['Python', 'Scrapy', 'Selenium', 'BeautifulSoup', 'PostgreSQL', 'Kafka'],
    date: '2024'
  },
  {
    id: 'api-integration-platform',
    title: 'Multi-API Integration Platform',
    category: 'API Integration',
    description: 'Developed a unified platform that seamlessly integrates with TMDB, YouTube, Weather APIs, and custom REST services.',
    challenge: 'Managing different API rate limits, authentication methods, error handling, and providing a consistent interface across diverse APIs.',
    solution: 'Created an abstraction layer with standardized request/response handling, implemented adaptive rate limiting, built comprehensive error recovery, and provided detailed logging and monitoring.',
    results: [
      'Reduced integration time by 80% for new APIs',
      'Achieved 99.8% API availability through redundancy',
      'Implemented smart caching reducing API calls by 65%',
      'Created self-healing system for automatic error recovery'
    ],
    technologies: ['Python', 'FastAPI', 'Redis', 'PostgreSQL', 'Docker', 'Kubernetes'],
    date: '2024'
  },
  {
    id: 'ml-model-deployment',
    title: 'Machine Learning Model Deployment',
    category: 'Machine Learning',
    description: 'Deployed production-ready ML models for classification and prediction tasks with real-time inference capabilities.',
    challenge: 'Ensuring model accuracy, managing model versioning, handling real-time predictions, and maintaining system performance under load.',
    solution: 'Used FastAPI for high-performance serving, implemented model versioning with A/B testing, created monitoring for model drift, and optimized inference with quantization.',
    results: [
      'Achieved 94% accuracy on classification tasks',
      'Reduced inference latency to <100ms per request',
      'Implemented automatic model retraining pipeline',
      'Scaled to handle 1000+ predictions per second'
    ],
    technologies: ['Python', 'TensorFlow', 'FastAPI', 'Docker', 'Prometheus', 'Grafana'],
    date: '2024'
  },
  {
    id: 'security-research-tool',
    title: 'Educational Security Research Tool',
    category: 'Security Research',
    description: 'Developed an authorized security testing tool for educational purposes and authorized penetration testing.',
    challenge: 'Creating a tool that is powerful for authorized testing but includes safeguards to prevent misuse.',
    solution: 'Implemented comprehensive logging, authentication, authorization checks, and created detailed documentation for responsible use.',
    results: [
      'Identified and documented 50+ security vulnerabilities',
      'Reduced security assessment time by 70%',
      'Created comprehensive audit trail for all operations',
      'Achieved ISO 27001 compliance for security practices'
    ],
    technologies: ['Python', 'Scapy', 'Metasploit', 'SQLite', 'Flask', 'OpenSSL'],
    date: '2024'
  },
  {
    id: 'data-analytics-dashboard',
    title: 'Real-Time Data Analytics Dashboard',
    category: 'Data Analysis',
    description: 'Built a comprehensive analytics dashboard that processes and visualizes real-time data from multiple sources.',
    challenge: 'Handling high-frequency data ingestion, real-time processing, and providing responsive visualizations for large datasets.',
    solution: 'Used Streamlit for rapid development, integrated Pandas for data processing, implemented Plotly for interactive visualizations, and used Kafka for real-time data streaming.',
    results: [
      'Processed 100,000+ data points per minute',
      'Reduced report generation time from hours to seconds',
      'Enabled real-time decision making for business teams',
      'Improved data accessibility across organization'
    ],
    technologies: ['Python', 'Streamlit', 'Pandas', 'Plotly', 'PostgreSQL', 'Kafka'],
    date: '2024'
  }
];

export default function CaseStudies() {
  const [, setLocation] = useLocation();
  const [selectedStudy, setSelectedStudy] = useState<CaseStudy | null>(null);

  if (selectedStudy) {
    return (
      <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
        <Enhanced3DBackground />

        {/* Header */}
        <div className="fixed top-0 w-full bg-background/95 backdrop-blur border-b border-dashed border-border z-40 py-6">
          <div className="container flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSelectedStudy(null)}
              className="border border-dashed border-border"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-2xl font-bold uppercase tracking-widest">Back to Case Studies</h1>
          </div>
        </div>

        {/* Case Study Detail */}
        <div className="pt-24 pb-20 relative z-10">
          <div className="container max-w-4xl">
            <Section3DTransition sectionId="case-study-detail">
              <div className="space-y-12">
                {/* Header */}
                <div className="space-y-4">
                  <div className="text-sm uppercase tracking-widest text-accent">{selectedStudy.category}</div>
                  <h1 className="text-5xl md:text-6xl font-bold uppercase tracking-widest">{selectedStudy.title}</h1>
                  <p className="text-lg text-muted-foreground">{selectedStudy.date}</p>
                </div>

                {/* Overview */}
                <div className="space-y-6 border-t border-dashed border-border pt-8">
                  <div>
                    <h2 className="text-2xl font-bold uppercase tracking-widest mb-4">Overview</h2>
                    <p className="text-lg text-muted-foreground leading-relaxed">{selectedStudy.description}</p>
                  </div>
                </div>

                {/* Challenge */}
                <div className="space-y-6 border-t border-dashed border-border pt-8">
                  <div>
                    <h2 className="text-2xl font-bold uppercase tracking-widest mb-4">Challenge</h2>
                    <p className="text-lg text-muted-foreground leading-relaxed">{selectedStudy.challenge}</p>
                  </div>
                </div>

                {/* Solution */}
                <div className="space-y-6 border-t border-dashed border-border pt-8">
                  <div>
                    <h2 className="text-2xl font-bold uppercase tracking-widest mb-4">Solution</h2>
                    <p className="text-lg text-muted-foreground leading-relaxed">{selectedStudy.solution}</p>
                  </div>
                </div>

                {/* Results */}
                <div className="space-y-6 border-t border-dashed border-border pt-8">
                  <div>
                    <h2 className="text-2xl font-bold uppercase tracking-widest mb-4">Results</h2>
                    <ul className="space-y-3">
                      {selectedStudy.results.map((result, idx) => (
                        <li key={idx} className="flex gap-4 text-lg text-muted-foreground">
                          <span className="text-accent font-bold">✓</span>
                          <span>{result}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Technologies */}
                <div className="space-y-6 border-t border-dashed border-border pt-8">
                  <div>
                    <h2 className="text-2xl font-bold uppercase tracking-widest mb-4">Technologies</h2>
                    <div className="flex flex-wrap gap-3">
                      {selectedStudy.technologies.map((tech) => (
                        <span
                          key={tech}
                          className="px-4 py-2 border-2 border-dashed border-accent text-accent text-sm uppercase tracking-widest"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Back Button */}
                <div className="border-t border-dashed border-border pt-8">
                  <Button
                    onClick={() => setSelectedStudy(null)}
                    className="uppercase tracking-widest"
                  >
                    Back to All Case Studies
                  </Button>
                </div>
              </div>
            </Section3DTransition>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Enhanced3DBackground />

      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-background/95 backdrop-blur border-b border-dashed border-border z-40 py-6">
        <div className="container flex justify-between items-center">
          <h1 className="text-xl font-bold uppercase tracking-wider">Case Studies</h1>
          <Button
            variant="ghost"
            onClick={() => setLocation('/')}
            className="border border-dashed border-border"
          >
            Back to Home
          </Button>
        </div>
      </nav>

      {/* Content */}
      <div className="pt-24 pb-20 relative z-10">
        <div className="container">
          <Section3DTransition sectionId="case-studies">
            <div className="space-y-12">
              <div className="space-y-4 mb-16">
                <h2 className="text-5xl md:text-6xl font-bold uppercase tracking-widest">Case Studies</h2>
                <p className="text-lg text-muted-foreground max-w-2xl">
                  Explore detailed case studies of my most impactful projects, showcasing challenges solved, solutions implemented, and results achieved.
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                {caseStudies.map((study) => (
                  <div
                    key={study.id}
                    onClick={() => setSelectedStudy(study)}
                    className="group cursor-pointer border-2 border-dashed border-border p-8 hover:border-accent hover:bg-accent/5 transition-all duration-300 space-y-4"
                  >
                    <div className="text-sm uppercase tracking-widest text-accent">{study.category}</div>
                    <h3 className="text-2xl font-bold uppercase tracking-widest group-hover:text-accent transition-colors">
                      {study.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed line-clamp-3">{study.description}</p>
                    <div className="flex flex-wrap gap-2 pt-4">
                      {study.technologies.slice(0, 3).map((tech) => (
                        <span key={tech} className="text-xs uppercase tracking-widest text-muted-foreground">
                          {tech}
                        </span>
                      ))}
                      {study.technologies.length > 3 && (
                        <span className="text-xs uppercase tracking-widest text-muted-foreground">
                          +{study.technologies.length - 3} more
                        </span>
                      )}
                    </div>
                    <div className="pt-4 border-t border-dashed border-border">
                      <Button
                        variant="outline"
                        size="sm"
                        className="uppercase tracking-widest text-xs group-hover:bg-accent group-hover:text-background transition-colors"
                      >
                        Read More
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Section3DTransition>
        </div>
      </div>
    </div>
  );
}
