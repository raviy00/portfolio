import { useEffect, useRef } from 'react';

interface Dot {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
}

export default function DottedNetworkBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resizeCanvas();

    // Create dots
    const dotsCount = 50;
    const dots: Dot[] = [];
    const connectionDistance = 150;

    for (let i = 0; i < dotsCount; i++) {
      dots.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        radius: Math.random() * 1.5 + 0.5,
      });
    }

    // Animation loop
    const animate = () => {
      // Get current theme
      const isDark = document.documentElement.classList.contains('dark');
      const dotColor = isDark ? 'rgba(255, 100, 100, 0.5)' : 'rgba(200, 50, 50, 0.4)';
      const lineColor = isDark ? 'rgba(255, 100, 100, 0.1)' : 'rgba(200, 50, 50, 0.1)';
      const bgColor = isDark ? 'rgba(13, 13, 13, 0.02)' : 'rgba(255, 255, 255, 0.02)';

      // Clear canvas with fade effect
      ctx.fillStyle = bgColor;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Update and draw dots
      dots.forEach((dot, i) => {
        // Update position
        dot.x += dot.vx;
        dot.y += dot.vy;

        // Bounce off edges
        if (dot.x - dot.radius < 0 || dot.x + dot.radius > canvas.width) {
          dot.vx *= -1;
          dot.x = Math.max(dot.radius, Math.min(canvas.width - dot.radius, dot.x));
        }
        if (dot.y - dot.radius < 0 || dot.y + dot.radius > canvas.height) {
          dot.vy *= -1;
          dot.y = Math.max(dot.radius, Math.min(canvas.height - dot.radius, dot.y));
        }

        // Draw dot
        ctx.fillStyle = dotColor;
        ctx.beginPath();
        ctx.arc(dot.x, dot.y, dot.radius, 0, Math.PI * 2);
        ctx.fill();

        // Draw connections
        for (let j = i + 1; j < dots.length; j++) {
          const dx = dots[j].x - dot.x;
          const dy = dots[j].y - dot.y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < connectionDistance) {
            ctx.strokeStyle = lineColor;
            ctx.lineWidth = 0.5;
            ctx.beginPath();
            ctx.moveTo(dot.x, dot.y);
            ctx.lineTo(dots[j].x, dots[j].y);
            ctx.stroke();
          }
        }
      });

      requestAnimationFrame(animate);
    };

    animate();

    // Handle window resize
    const handleResize = () => {
      resizeCanvas();
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0"
      style={{ opacity: 0.5 }}
    />
  );
}
