import { useLanguage } from '@/contexts/LanguageContext';

export default function LanguageSelector() {
  const { language, setLanguage } = useLanguage();

  return (
    <div className="flex items-center gap-4 px-4 py-2 border border-dashed border-border rounded">
      <span className="text-xs uppercase tracking-widest text-muted-foreground">Language:</span>
      <div className="flex gap-4">
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="radio"
            name="language"
            value="en"
            checked={language === 'en'}
            onChange={(e) => setLanguage(e.target.value as 'en' | 'de')}
            className="w-4 h-4 cursor-pointer"
          />
          <span className="text-sm">English</span>
        </label>
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="radio"
            name="language"
            value="de"
            checked={language === 'de'}
            onChange={(e) => setLanguage(e.target.value as 'en' | 'de')}
            className="w-4 h-4 cursor-pointer"
          />
          <span className="text-sm">Deutsch</span>
        </label>
      </div>
    </div>
  );
}
