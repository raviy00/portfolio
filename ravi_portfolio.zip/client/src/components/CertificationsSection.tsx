import { useRef } from 'react';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { useTranslation } from '@/contexts/LanguageContext';

interface Certification {
  id: string;
  titleKey: string;
  issuer: string;
  status: 'completed' | 'inProgress';
}

const certifications: Certification[] = [
  {
    id: 'intro-cyber',
    titleKey: 'introCybersecurity',
    issuer: 'ciscoNetworkingAcademy',
    status: 'completed',
  },
  {
    id: 'it-customer',
    titleKey: 'itCustomerSupport',
    issuer: 'ciscoNetworkingAcademy',
    status: 'completed',
  },
  {
    id: 'networking',
    titleKey: 'networkingBasics',
    issuer: 'ciscoNetworkingAcademy',
    status: 'inProgress',
  },
  {
    id: 'ethical-hacker',
    titleKey: 'ethicalHacker',
    issuer: 'ciscoNetworkingAcademy',
    status: 'inProgress',
  },
  {
    id: 'iot',
    titleKey: 'introIoT',
    issuer: 'ciscoNetworkingAcademy',
    status: 'inProgress',
  },
];

export default function CertificationsSection() {
  const ref = useScrollAnimation();
  const t = useTranslation();

  const completedCerts = certifications.filter((c) => c.status === 'completed');
  const inProgressCerts = certifications.filter((c) => c.status === 'inProgress');

  const CertificationCard = ({ cert }: { cert: Certification }) => (
    <div className="scroll-animate opacity-0 border-2 border-dashed border-accent/50 p-6 hover:border-accent transition-colors duration-300">
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-full border-2 border-accent flex items-center justify-center flex-shrink-0 text-lg font-bold">
          🎓
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="text-lg font-bold uppercase tracking-wider mb-1">
            {t[cert.titleKey as keyof typeof t]}
          </h4>
          <p className="text-sm text-muted-foreground mb-3">
            {t[cert.issuer as keyof typeof t]}
          </p>
          <div className="w-full h-24 border-2 border-dashed border-accent/30 rounded flex items-center justify-center text-xs text-muted-foreground hover:border-accent/50 transition-colors">
            📄 Certificate Image
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <section ref={ref} className="py-16 md:py-20 bg-card/50 relative z-10 px-4 md:px-6">
      <div className="container">
        <h2 className="section-title mb-8 md:mb-12">Certifications</h2>

        {/* Completed Certifications */}
        <div className="mb-12 md:mb-16">
          <h3 className="text-lg md:text-xl font-bold uppercase tracking-widest text-accent mb-6">
            {t.completedCertifications}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
            {completedCerts.map((cert) => (
              <CertificationCard key={cert.id} cert={cert} />
            ))}
          </div>
        </div>

        {/* In Progress Certifications */}
        <div>
          <h3 className="text-lg md:text-xl font-bold uppercase tracking-widest text-accent mb-6">
            {t.inProgressCertifications}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            {inProgressCerts.map((cert) => (
              <CertificationCard key={cert.id} cert={cert} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
