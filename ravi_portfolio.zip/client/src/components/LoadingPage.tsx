import { useEffect, useRef, useState } from 'react';
import { ThreeScene } from '@/lib/ThreeScene';
import gsap from 'gsap';

interface LoadingPageProps {
  onComplete: () => void;
}

export default function LoadingPage({ onComplete }: LoadingPageProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<ThreeScene | null>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!containerRef.current) return;

    // Initialize Three.js scene
    sceneRef.current = new ThreeScene(containerRef.current);

    // Create 3D objects for loading animation
    const geometry1 = sceneRef.current.createWireframeGeometry('box');
    const geometry2 = sceneRef.current.createWireframeGeometry('sphere');
    const geometry3 = sceneRef.current.createWireframeGeometry('torus');

    geometry1.position.set(-3, 0, 0);
    geometry2.position.set(0, 0, 0);
    geometry3.position.set(3, 0, 0);

    // Animate loading progress
    const progressTimeline = gsap.timeline();
    progressTimeline.to(
      { progress: 0 },
      {
        progress: 100,
        duration: 2,
        onUpdate: function () {
          setProgress(Math.round(this.targets()[0].progress));
        },
      }
    );

    // Animate objects
    gsap.to(geometry1.position, {
      y: 2,
      duration: 1,
      repeat: -1,
      yoyo: true,
      ease: 'sine.inOut',
    });

    gsap.to(geometry2.position, {
      y: -2,
      duration: 1,
      repeat: -1,
      yoyo: true,
      ease: 'sine.inOut',
    });

    gsap.to(geometry3.position, {
      y: 2,
      duration: 1,
      repeat: -1,
      yoyo: true,
      ease: 'sine.inOut',
    });

    // Complete loading after 2 seconds
    const timer = setTimeout(() => {
      gsap.to(containerRef.current, {
        opacity: 0,
        duration: 0.8,
        onComplete: () => {
          if (sceneRef.current) {
            sceneRef.current.dispose();
          }
          onComplete();
        },
      });
    }, 2800);

    return () => {
      clearTimeout(timer);
      if (sceneRef.current) {
        sceneRef.current.dispose();
      }
    };
  }, [onComplete]);

  return (
    <div className="fixed inset-0 bg-background z-50 flex flex-col items-center justify-center">
      <div
        ref={containerRef}
        className="absolute inset-0"
        style={{ width: '100%', height: '100%' }}
      />
      <div className="relative z-10 text-center">
        <h1 className="text-4xl font-bold uppercase tracking-widest text-foreground mb-8">
          Loading
        </h1>
        <div className="w-64 h-1 bg-border rounded-full overflow-hidden">
          <div
            className="h-full bg-accent transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="text-muted-foreground mt-6 text-sm uppercase tracking-wider">
          {progress}%
        </p>
      </div>
    </div>
  );
}
